<script src="assets/js/index.js"></script>
<script src="assets/js/investments.js"></script>
